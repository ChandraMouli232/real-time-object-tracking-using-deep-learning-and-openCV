from flask import Flask,render_template,redirect,request,url_for
import pickle
import joblib

app = Flask(__name__)

@app.route("/",methods=["GET","POST"])
def prediction():
    if request.method == "POST":
        code = request.form['postal_code']
        month = request.form['month']
        year = request.form['year']
        week = request.form['week']

        new_values = [[code,month,year,week]]
        model = joblib.load("models/decision.joblib")
        pred = model.predict(new_values)
        print(pred,11948390589275194)

        return render_template("predection.html",pred=pred )
    return render_template("predection.html")
if __name__ == "__main__":
    app.run(debug=True)